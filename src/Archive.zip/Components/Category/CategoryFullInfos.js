export const CategoryInfos = [
  {
    title: "Electonics",
    name: "electronics",
    imgLink: "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_t.png",
  },
  {
    title: "Discover fasion trends",
    name: "Women's closing",
    imgLink: " https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_t.png",
  },
  {
    title: "Men'sClothing",
    name: "men's clothing",
    imgLink: "zhttps://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_t.png",
  },
  {
    title: "Jewlery",
    name: "jewlery",
    imgLink:
      "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_t.png",
  },
];
                                                                                                                                                            